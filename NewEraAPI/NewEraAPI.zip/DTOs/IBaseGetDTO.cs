﻿namespace NewEraAPI.DTOs
{
    public interface IBaseGetDTO
    {
        public int ID { get; set; }
    }
}
