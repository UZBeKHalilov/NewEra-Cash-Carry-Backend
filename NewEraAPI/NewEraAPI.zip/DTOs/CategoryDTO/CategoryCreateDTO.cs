﻿namespace NewEraAPI.DTOs.CategoryDTO
{
    public class CategoryCreateDTO
    {
        public string Name { get; set; }
        public string Description { get; set; }

    }
}
