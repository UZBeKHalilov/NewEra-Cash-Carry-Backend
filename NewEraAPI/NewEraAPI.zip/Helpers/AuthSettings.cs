﻿namespace NewEraAPI.Helpers
{
    public class AuthSettings
    {
        public string Secret { get; set; }
    }
}
